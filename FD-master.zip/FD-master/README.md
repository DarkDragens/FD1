# FD
Дневник питания для Android

![Screenshot 0](/app/src/main/java/com/witchnwitcher/fd/screen.jpg)
![Screenshot 1](/app/src/main/java/com/witchnwitcher/fd/screen1.jpg)
![Screenshot 2](/app/src/main/java/com/witchnwitcher/fd/screen2.jpg)
![Screenshot 3](/app/src/main/java/com/witchnwitcher/fd/screen3.jpg)
